import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import time

# Konfigurasi Tampilan Dashboard
st.set_page_config(
    page_title="Team ZERO - IoT Dashboard",
    page_icon="",
    layout="wide"
)

def muat_css(nama_file):
    with open(nama_file) as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

muat_css("style.css")


# Endpoint API Backend Laravel
URL_API = "http://127.0.0.1:8000/api/monitoring-data"

st.title("Dashboard Monitoring Jarak Sensor")
st.write("Projek IoT Real-time System - Team ZERO")
st.markdown("---")

# ==========================================
# 1. FUNGSI LOGIKA FUZZY
# ==========================================
def hitung_keanggotaan(jarak):
    """Menghitung derajat keanggotaan (µ) untuk himpunan Dekat, Sedang, dan Jauh"""
    # Himpunan Dekat
    if jarak <= 15:
        mu_dekat = 1.0
    elif 15 < jarak <= 30:
        mu_dekat = (30 - jarak) / 15.0
    else:
        mu_dekat = 0.0

    # Himpunan Sedang
    if jarak <= 15 or jarak > 45:
        mu_sedang = 0.0
    elif 15 < jarak <= 30:
        mu_sedang = (jarak - 15) / 15.0
    elif 30 < jarak <= 45:
        mu_sedang = (45 - jarak) / 15.0
    else:
        mu_sedang = 0.0

    # Himpunan Jauh
    if jarak <= 30:
        mu_jauh = 0.0
    elif 30 < jarak <= 45:
        mu_jauh = (jarak - 30) / 15.0
    else:
        mu_jauh = 1.0

    return mu_dekat, mu_sedang, mu_jauh


# ==========================================
# 2. FUNGSI GRAFIK FUZZY INDIVIDUAL (PER SENSOR)
# ==========================================
def buat_grafik_fuzzy(jarak_aktual, nama_sensor):
    """Membuat grafik fungsi keanggotaan fuzzy dengan garis vertikal penunjuk jarak asli"""
    x_vals = np.linspace(0, 60, 300)
    y_dekat = [hitung_keanggotaan(x)[0] for x in x_vals]
    y_sedang = [hitung_keanggotaan(x)[1] for x in x_vals]
    y_jauh = [hitung_keanggotaan(x)[2] for x in x_vals]

    fig = go.Figure()

    # Plot Kurva (Merah = Dekat, Kuning = Sedang, Hijau = Jauh)
    fig.add_trace(go.Scatter(x=x_vals, y=y_dekat, name='Dekat', line=dict(color='#ff4b4b', width=3)))
    fig.add_trace(go.Scatter(x=x_vals, y=y_sedang, name='Sedang', line=dict(color='#ffa500', width=3)))
    fig.add_trace(go.Scatter(x=x_vals, y=y_jauh, name='Jauh', line=dict(color='#00cb30', width=3)))

    # Garis Penunjuk Sensor Aktual (Perbaikan line_width)
    fig.add_vline(
        x=jarak_aktual, 
        line_dash="dash", 
        line_color="#1f77b4", 
        line_width=2.5, 
        annotation_text=f"Jarak: {jarak_aktual} cm", 
        annotation_position="top right"
    )

    # Menyesuaikan tampilan grafik agar mirip contoh referensi gambar
    fig.update_layout(
        title=f"Distance Membership Functions - {nama_sensor}",
        xaxis_title="Distance (cm)",
        yaxis_title="Membership Degree (µ)",
        yaxis=dict(range=[-0.05, 1.05]),
        height=240,
        margin=dict(l=20, r=20, t=45, b=20),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig


# ==========================================
# 3. AMBIL DATA DARI LARAVEL
# ==========================================
def ambil_data_dari_laravel():
    try:
        response = requests.get(URL_API, timeout=1.5)
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except:
        return None


# ==========================================
# MAIN ROUTINE & UI DISPLAY
# ==========================================
data_json = ambil_data_dari_laravel()

if data_json and len(data_json) > 0:
    df = pd.DataFrame(data_json)
    df = df.iloc[::-1].reset_index(drop=True) 
    
    data_terbaru = df.iloc[-1]
    j1 = float(data_terbaru['jarak1'])
    j2 = float(data_terbaru['jarak2'])
    j3 = float(data_terbaru['jarak3'])
    waktu_update = data_terbaru['waktu']

    # --- TAMPILAN CARD STATUS UTAMA ---
    col1, col2, col3 = st.columns(3)

    with col1:
        status1 = "SANGAT BAHAYA" if j1 <= 15.0 else "PERINGATAN" if 15.0 < j1 <= 30.0 else "AMAN"
        st.metric(label="Sensor 1 (Bawah)", value=f"{j1} cm")
        st.markdown(f"Status: **{status1}**")

    with col2:
        status2 = "SANGAT BAHAYA" if j2 <= 15.0 else "PERINGATAN" if 15.0 < j2 <= 30.0 else "AMAN"
        st.metric(label="Sensor 2 (Tengah)", value=f"{j2} cm")
        st.markdown(f"Status: **{status2}**")

    with col3:
        status3 = "SANGAT BAHAYA" if j3 <= 15.0 else "PERINGATAN" if 15.0 < j3 <= 30.0 else "AMAN"
        st.metric(label="Sensor 3 (Atas)", value=f"{j3} cm")
        st.markdown(f"Status: **{status3}**")
        
    st.caption(f"Terakhir Diperbarui: {waktu_update}")
    st.markdown("---")

    # --- PANEL GRAFIK FUZZY INDIVIDUAL ---
    st.subheader("Analisis Grafik Logika Fuzzy per Sensor")
    st.write("Visualisasi kurva keanggotaan matematika Fuzzy untuk memetakan pembacaan sensor ke status keputusan.")

    # Kontainer Sensor 1
    with st.container(border=True):
        st.markdown("#### Kacamata Sensor 1 (Bawah)")
        c_data, c_graph = st.columns([1, 2])
        with c_data:
            mu_d1, mu_s1, mu_jh1 = hitung_keanggotaan(j1)
            st.write("**Nilai Derajat Keanggotaan (µ):**")
            st.progress(mu_d1, text=f"µ Dekat (Bahaya): {round(mu_d1, 2)}")
            st.progress(mu_s1, text=f"µ Sedang (Waspada): {round(mu_s1, 2)}")
            st.progress(mu_jh1, text=f"µ Jauh (Aman): {round(mu_jh1, 2)}")
        with c_graph:
            st.plotly_chart(buat_grafik_fuzzy(j1, "Sensor 1"), use_container_width=True)

    # Kontainer Sensor 2
    with st.container(border=True):
        st.markdown("#### Kacamata Sensor 2 (Tengah)")
        c_data, c_graph = st.columns([1, 2])
        with c_data:
            mu_d2, mu_s2, mu_jh2 = hitung_keanggotaan(j2)
            st.write("**Nilai Derajat Keanggotaan (µ):**")
            st.progress(mu_d2, text=f"µ Dekat (Bahaya): {round(mu_d2, 2)}")
            st.progress(mu_s2, text=f"µ Sedang (Waspada): {round(mu_s2, 2)}")
            st.progress(mu_jh2, text=f"µ Jauh (Aman): {round(mu_jh2, 2)}")
        with c_graph:
            st.plotly_chart(buat_grafik_fuzzy(j2, "Sensor 2"), use_container_width=True)

    # Kontainer Sensor 3
    with st.container(border=True):
        st.markdown("#### Kacamata Sensor 3 (Atas)")
        c_data, c_graph = st.columns([1, 2])
        with c_data:
            mu_d3, mu_s3, mu_jh3 = hitung_keanggotaan(j3)
            st.write("**Nilai Derajat Keanggotaan (µ):**")
            st.progress(mu_d3, text=f"µ Dekat (Bahaya): {round(mu_d3, 2)}")
            st.progress(mu_s3, text=f"µ Sedang (Waspada): {round(mu_s3, 2)}")
            st.progress(mu_jh3, text=f"µ Jauh (Aman): {round(mu_jh3, 2)}")
        with c_graph:
            st.plotly_chart(buat_grafik_fuzzy(j3, "Sensor 3"), use_container_width=True)

    st.markdown("---")

    # --- GRAFIK TREN REAL-TIME ---
    st.subheader("Grafik Tren Jarak Sensor (Real-time)")
    fig = px.line(df, x='waktu', y=['jarak1', 'jarak2', 'jarak3'],
                  labels={'value': 'Jarak (cm)', 'waktu': 'Waktu', 'variable': 'Sensor'},
                  title="Pergerakan Objek Terhadap Kacamata Sensor")
    st.plotly_chart(fig, use_container_width=True)
    st.markdown("---")

    # --- TABEL DATA & TOMBOL DOWNLOAD ---
    st.subheader("Tabel Riwayat Data")
    st.dataframe(df.iloc[::-1], use_container_width=True)
    
    csv_data = df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="Unduh Semua Laporan (CSV)",
        data=csv_data,
        file_name='laporan_sensor_team_zero.csv',
        mime='text/csv',
    )

else:
    st.warning("Menunggu suplai data dari Backend Laravel... Pastikan 'php artisan serve' kamu aktif.")
    st.info(f"Mencoba menyambung ke API: {URL_API}")

# Interval Penyegaran Dashboard 2 detik
time.sleep(2)
st.rerun()
