import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import time

# ==========================================
# 1. CONFIG & SYSTEM THEME INJECTION
# ==========================================
st.set_page_config(
    page_title="Team ZERO - IoT Telemetry",
    page_icon="📡",
    layout="wide"
)

# Memaksa warna latar belakang dasar Streamlit menjadi gelap pekat sesuai gambar
st.markdown("""
    <style>
    [data-testid="stAppViewContainer"] {
        background-color: #060913;
    }
    [data-testid="stHeader"] {
        background-color: rgba(0,0,0,0);
    }
    .reportview-container {
        background-color: #060913;
    }
    h1, h2, h3, h4, h5, h6, p, span {
        color: #ffffff;
    }
    </style>
""", unsafe_allow_html=True)

URL_API = "http://127.0.0.1:8000/api/monitoring-data"


# ==========================================
# 2. LOGIKA FUZZY MATEMATIKA
# ==========================================
def hitung_keanggotaan(jarak):
    # Himpunan Dekat
    if jarak <= 15:
        mu_dekat = 1.0
    elif 15 < jarak <= 30:
        mu_dekat = (30 - jarak) / 15.0
    else:
        mu_dekat = 0.0

    # Himpunan Sedang
    if jarak <= 15 or jarak > 45:
        mu_sedang = 0.0
    elif 15 < jarak <= 30:
        mu_sedang = (jarak - 15) / 15.0
    elif 30 < jarak <= 45:
        mu_sedang = (45 - jarak) / 15.0
    else:
        mu_sedang = 0.0

    # Himpunan Jauh
    if jarak <= 30:
        mu_jauh = 0.0
    elif 30 < jarak <= 45:
        mu_jauh = (jarak - 30) / 15.0
    else:
        mu_jauh = 1.0

    return mu_dekat, mu_sedang, mu_jauh


# ==========================================
# 3. FUNGSI EMIT STYLED GRAPH (PLOTLY CYBERPUNK)
# ==========================================
def buat_grafik_fuzzy_cyber(jarak_aktual, nama_sensor):
    x_vals = np.linspace(0, 60, 300)
    y_dekat = [hitung_keanggotaan(x)[0] for x in x_vals]
    y_sedang = [hitung_keanggotaan(x)[1] for x in x_vals]
    y_jauh = [hitung_keanggotaan(x)[2] for x in x_vals]

    fig = go.Figure()

    # Sesuaikan garis warna dengan tema dark (Neon Red, Neon Amber, Neon Cyan/Green)
    fig.add_trace(go.Scatter(x=x_vals, y=y_dekat, name='Dekat', line=dict(color='#ff4b5c', width=2.5)))
    fig.add_trace(go.Scatter(x=x_vals, y=y_sedang, name='Sedang', line=dict(color='#ffb830', width=2.5)))
    fig.add_trace(go.Scatter(x=x_vals, y=y_jauh, name='Jauh', line=dict(color='#00f5a0', width=2.5)))

    # Garis penanda titik aktual real-time
    fig.add_vline(
        x=jarak_aktual, 
        line_dash="dash", 
        line_color="#00bbf9", 
        line_width=2, 
        annotation_text=f"{jarak_aktual} cm", 
        annotation_position="top left",
        annotation_font=dict(color="#00bbf9", size=10)
    )

    fig.update_layout(
        title=dict(
            text=f"MEMBERSHIP FUNCTION - {nama_sensor.upper()}",
            font=dict(color='#9ca3af', size=11, family="monospace")
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(showgrid=True, gridcolor='#1e293b', title=None, tickfont=dict(color='#64748b', size=9)),
        yaxis=dict(showgrid=True, gridcolor='#1e293b', title=None, range=[-0.05, 1.05], tickfont=dict(color='#64748b', size=9)),
        height=180,
        margin=dict(l=20, r=20, t=35, b=20),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, font=dict(color='#64748b', size=9))
    )
    return fig


def ambil_data_dari_laravel():
    try:
        response = requests.get(URL_API, timeout=1.5)
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except:
        return None

# ==========================================
# MAIN ROUTINE ENTRYPOINT
# ==========================================
data_json = ambil_data_dari_laravel()

if data_json and len(data_json) > 0:
    df = pd.DataFrame(data_json)
    df = df.iloc[::-1].reset_index(drop=True) 
    
    data_terbaru = df.iloc[-1]
    j1 = float(data_terbaru['jarak1'])
    j2 = float(data_terbaru['jarak2'])
    j3 = float(data_terbaru['jarak3'])
    waktu_update = data_terbaru['waktu']

    # --- HEADER PANEL (KUSTOM HTML SEPERTI DI GAMBAR) ---
    st.markdown(f"""
        <div style="background-color: #0b0f19; border: 1px solid #1e293b; border-radius: 12px; padding: 20px; margin-bottom: 25px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <div>
                    <span style="background-color: rgba(0,245,160,0.05); color: #00f5a0; border: 1px solid #00f5a0; padding: 4px 12px; border-radius: 50px; font-size: 11px; font-weight: bold; font-family: monospace; letter-spacing: 1px;">• TEAM ZERO • IOT TELEMETRY</span>
                    <div style="color: #94a3b8; font-size: 13px; font-family: sans-serif; font-weight: 600; margin-top: 12px; letter-spacing: 0.5px;">REAL-TIME FUZZY DECISION SYSTEM • THREE-CHANNEL ULTRASONIC MESH</div>
                </div>
                <div style="display: flex; gap: 25px; text-align: left; font-family: monospace; font-size: 11px;">
                    <div><span style="color: #64748b;">STATUS</span><br><span style="color: #ffb830; font-weight: bold;">LIVE MODE</span></div>
                    <div><span style="color: #64748b;">LAST SYNC</span><br><span style="color: #ffffff; font-weight: bold;">{waktu_update}</span></div>
                    <div><span style="color: #64748b;">SAMPLES</span><br><span style="color: #ffffff; font-weight: bold;">{len(df)}</span></div>
                    <div><span style="color: #64748b;">REFRESH</span><br><span style="color: #00f5a0; font-weight: bold;">2.0 s</span></div>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # ==========================================
    # SECTION 01: PEMBACAAN SENSOR AKTIF
    # ==========================================
    st.markdown("""
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <span style="background-color: rgba(0,187,249,0.1); color: #00bbf9; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; font-family: monospace; border: 1px solid rgba(0,187,249,0.3); margin-right: 12px;">01 / OVERVIEW</span>
            <span style="color: #ffffff; font-size: 16px; font-weight: 600; letter-spacing: 0.5px;">Pembacaan Sensor Aktif</span>
        </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    
    # Setup data pendukung visual komponen card sensor
    sensor_configs = [
        {"jarak": j1, "label": "SENSOR 1 - BAWAH", "ch": "CH-01"},
        {"jarak": j2, "label": "SENSOR 2 - TENGAH", "ch": "CH-02"},
        {"jarak": j3, "label": "SENSOR 3 - ATAS", "ch": "CH-03"}
    ]

    for idx, col in enumerate([col1, col2, col3]):
        conf = sensor_configs[idx]
        j_val = conf["jarak"]
        
        if j_val <= 15.0:
            status_txt, clr, bg_clr = "SANGAT BAHAYA", "#ff4b5c", "rgba(255, 75, 92, 0.1)"
        elif 15.0 < j_val <= 30.0:
            status_txt, clr, bg_clr = "PERINGATAN", "#ffb830", "rgba(255, 184, 48, 0.1)"
        else:
            status_txt, clr, bg_clr = "AMAN", "#00f5a0", "rgba(0, 245, 160, 0.1)"
            
        with col:
            st.markdown(f"""
                <div style="background-color: #0b0f19; border: 1px solid #1e293b; border-radius: 12px; padding: 20px; border-left: 4px solid {clr}; font-family: sans-serif;">
                    <div style="display: flex; justify-content: space-between; color: #64748b; font-size: 11px; font-weight: bold; font-family: monospace;">
                        <span>{conf["label"]}</span>
                        <span>{conf["ch"]}</span>
                    </div>
                    <div style="font-size: 44px; font-weight: bold; color: #ffffff; margin: 12px 0;">
                        {j_val} <span style="font-size: 16px; color: #64748b; font-weight: normal;">cm</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #1e293b; padding-top: 12px; margin-top: 8px;">
                        <span style="background-color: {bg_clr}; color: {clr}; padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: bold; font-family: monospace; border: 1px solid {clr}50;">● {status_txt}</span>
                        <span style="color: #475569; font-size: 10px; font-family: monospace;">RANGE 0-60 CM</span>
                    </div>
                </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ==========================================
    # SECTION 02: ANALISIS KURVA KEANGGOTAAN
    # ==========================================
    st.markdown("""
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <span style="background-color: rgba(0,187,249,0.1); color: #00bbf9; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; font-family: monospace; border: 1px solid rgba(0,187,249,0.3); margin-right: 12px;">02 / FUZZY ANALYSIS</span>
            <span style="color: #ffffff; font-size: 16px; font-weight: 600; letter-spacing: 0.5px;">Analisis Kurva Keanggotaan</span>
        </div>
        <p style="color: #64748b; font-size: 12px; margin-left: 5px; margin-bottom: 20px;">Memetakan pembacaan sensor ke himpunan fuzzy Dekat, Sedang, dan Jauh untuk pengambilan keputusan adaptif.</p>
    """, unsafe_allow_html=True)

    # Render List Analisis untuk Setiap Sensor Terpisah
    sensor_data_list = [
        {"val": j1, "tag": "S1", "nama": "Kacamata Sensor 1 (Bawah)"},
        {"val": j2, "tag": "S2", "nama": "Kacamata Sensor 2 (Tengah)"},
        {"val": j3, "tag": "S3", "nama": "Kacamata Sensor 3 (Atas)"}
    ]

    for s_info in sensor_data_list:
        v = s_info["val"]
        mu_d, mu_s, mu_jh = hitung_keanggotaan(v)
        
        # Cari himpunan dominan
        himpunan_arr = [("DEKAT (BAHAYA)", mu_d), ("SEDANG (WASPADA)", mu_s), ("JAUH (AMAN)", mu_jh)]
        dominan_nama, dominan_val = max(himpunan_arr, key=lambda item: item[1])

        # Render Wrapper Box Luar Card Fuzzy per Sensor
        with st.container():
            st.markdown(f"""
                <div style="background-color: #0b0f19; border: 1px solid #1e293b; border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                    <div style="color: #ffffff; font-size: 14px; font-weight: bold; font-family: sans-serif; display: flex; align-items: center; gap: 10px;">
                        <span style="background-color: #1e293b; color: #00bbf9; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-family: monospace;">{s_info["tag"]}</span> {s_info["nama"]}
                    </div>
                    <div style="color: #00bbf9; font-size: 10px; font-family: monospace; font-weight: bold; letter-spacing: 1px; margin-top: 6px; margin-bottom: 15px;">
                        FUZZY MEMBERSHIP • DOMINAN: {dominan_nama} ({round(dominan_val, 2)})
                    </div>
                </div>
            """, unsafe_allow_html=True)
            
            # Membagi isi card menjadi Kolom Kiri (Progress Bar) dan Kolom Kanan (Grafik)
            # Menggunakan teknik tumpang tindih margin agar rapi menyatu ke dalam bodi kontainer HTML diatas
            st.markdown("<div style='margin-top: -35px;'></div>", unsafe_allow_html=True)
            inner_col1, inner_col2 = st.columns([2, 3])
            
            with inner_col1:
                st.markdown("<div style='padding-left: 20px; padding-top: 15px;'>", unsafe_allow_html=True)
                
                # Custom progress bar horizontal buatan sendiri agar persis CSS di gambar
                def render_custom_bar(lbl, val, color_hex):
                    st.markdown(f"""
                        <div style="margin-bottom: 14px; font-family: monospace;">
                            <div style="display: flex; justify-content: space-between; color: #94a3b8; font-size: 10px; font-weight: bold; margin-bottom: 5px;">
                                <span>{lbl}</span>
                                <span style="color: #ffffff;">{val:.2f}</span>
                            </div>
                            <div style="background-color: #1e293b; height: 5px; border-radius: 10px; overflow: hidden;">
                                <div style="background-color: {color_hex}; width: {val * 100}%; height: 100%; border-radius: 10px;"></div>
                            </div>
                        </div>
                    """, unsafe_allow_html=True)

                render_custom_bar("µ DEKAT - BAHAYA", mu_d, "#ff4b5c")
                render_custom_bar("µ SEDANG - WASPADA", mu_s, "#ffb830")
                render_custom_bar("µ JAUH - AMAN", mu_jh, "#00f5a0")
                st.markdown("</div>", unsafe_allow_html=True)
                
            with inner_col2:
                # BAGIAN INI SUDAH DIPERBAIKI MENJADI buat_grafik_fuzzy_cyber
                st.plotly_chart(buat_grafik_fuzzy_cyber(v, s_info["tag"]), use_container_width=True)
            
            st.markdown("<div style='margin-bottom: 15px;'></div>", unsafe_allow_html=True)

    # ==========================================
    # DATA ARCHIVE SECTION
    # ==========================================
    st.markdown("---")
    st.subheader("📈 Grafik Tren Jarak Sensor (Real-time)")
    fig_line = px.line(df, x='waktu', y=['jarak1', 'jarak2', 'jarak3'],
                  labels={'value': 'Jarak (cm)', 'waktu': 'Waktu', 'variable': 'Sensor'})
    fig_line.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font=dict(color='#64748b'))
    st.plotly_chart(fig_line, use_container_width=True)

    st.subheader("📋 Tabel Riwayat Data")
    st.dataframe(df.iloc[::-1], use_container_width=True)

else:
    st.warning("⚠️ Menunggu suplai data dari Backend Laravel... Pastikan 'php artisan serve' kamu aktif.")

# Loop Refresh Rate
time.sleep(2)
st.rerun()